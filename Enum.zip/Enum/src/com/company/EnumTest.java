package com.company;

public class EnumTest {
    Day day;
    
    public EnumTest(Day day) {
        this.day = day;
    }

    public void tellItLikeItIs() {
        switch (day) {
            case MONDAY:
                System.out.println("周一各种不在状态");
                break;
            case FRIDAY:
                System.out.println("周五感觉还不错");
                break;
            case SATURDAY: case SUNDAY:
                System.out.println("周末给人的感觉是最棒的");
                break;
            default:
                System.out.println("周内的感觉就那样吧。。。");
                break;
        }
    }

    public enum Day {
        SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
    }

}
