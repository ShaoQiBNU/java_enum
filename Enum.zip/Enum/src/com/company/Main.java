package com.company;

public class Main {

    public static void main(String[] args) {

    /* EnumTest
	EnumTest firstDay = new EnumTest(EnumTest.Day.SUNDAY);
	firstDay.tellItLikeItIs();

    EnumTest thirdDay = new EnumTest(EnumTest.Day.WEDNESDAY);
    thirdDay.tellItLikeItIs();

    EnumTest fifthDay = new EnumTest(EnumTest.Day.FRIDAY);
    fifthDay.tellItLikeItIs();

    EnumTest sixthDay = new EnumTest(EnumTest.Day.SATURDAY);
    sixthDay.tellItLikeItIs();

    EnumTest seventhDay = new EnumTest(EnumTest.Day.SUNDAY);
    seventhDay.tellItLikeItIs();
    */

    /*
    EnumTest2 firstDay = new EnumTest2(EnumTest2.Day.SUNDAY);
    firstDay.tellItLikeItIs();

    EnumTest2 thirdDay = new EnumTest2(EnumTest2.Day.WEDNESDAY);
    thirdDay.tellItLikeItIs();

    EnumTest2 fifthDay = new EnumTest2(EnumTest2.Day.FRIDAY);
    fifthDay.tellItLikeItIs();

    EnumTest2 sixthDay = new EnumTest2(EnumTest2.Day.SATURDAY);
    sixthDay.tellItLikeItIs();

    EnumTest2 seventhDay = new EnumTest2(EnumTest2.Day.SUNDAY);
    seventhDay.tellItLikeItIs();
    */

    EnumTest3 firstDay = new EnumTest3(EnumTest3.Day.SUNDAY);
    firstDay.tellItLikeItIs();

    EnumTest3 thirdDay = new EnumTest3(EnumTest3.Day.WEDNESDAY);
    thirdDay.tellItLikeItIs();

    EnumTest3 fifthDay = new EnumTest3(EnumTest3.Day.FRIDAY);
    fifthDay.tellItLikeItIs();

    EnumTest3 sixthDay = new EnumTest3(EnumTest3.Day.SATURDAY);
    sixthDay.tellItLikeItIs();

    EnumTest3 seventhDay = new EnumTest3(EnumTest3.Day.SUNDAY);
    seventhDay.tellItLikeItIs();

    }
}
